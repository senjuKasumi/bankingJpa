package com.cg.banking.client;

import java.sql.SQLException;
import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;


public class MainClass {

	public static void main(String[] args) throws SQLException {

		BankingServices bankingServices = new BankingServicesImpl();
		Scanner sc = new Scanner(System.in);
		String userChoice="y";
		while(userChoice.compareToIgnoreCase("y")==0){
			System.out.println("Banking Services!\n1. Open Account\n2. Deposit Amount\n3. Withdraw Amount\n4. Transfer amount\n5. Get account details\n6. Get all account details\n"
					+ "7. Get all transactions\n8. Get account status\nEnter your choice:");
			int option = sc.nextInt();
			switch(option){
			case 1:
				try{
					System.out.println("Enter the type of account: ");String accountType = sc.next();
					System.out.println("Enter initial balance: ");Float balance = sc.nextFloat();
					System.out.println("Account is open. Account no. is"+bankingServices.openAccount(accountType, balance));
				}catch (InvalidAmountException e) {
					System.out.println("Invalid Amount");
				}catch (InvalidAccountTypeException e) {
					System.out.println("Invalid Account");
				} catch (BankingServicesDownException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}break;

			case 2:
				try{
					System.out.println("Enter accountNo: ");long accountNo = sc.nextLong();
					System.out.println("Enter amount: ");float amount = sc.nextFloat();
					System.out.println("Account balance is"+bankingServices.depositAmount(accountNo, amount));
				}catch (BankingServicesDownException e) {
					System.out.println("Server is Down. Please try again later");
				}catch (AccountNotFoundException e) {
					System.out.println("Account not found");
				}catch (AccountBlockedException e) {
					System.out.println("Account is blocked");
				}break;

			case 3:
				try{
					System.out.println("Enter accountNo: ");long accountNo = sc.nextLong();
					System.out.println("Enter pin");int pinNo = sc.nextInt();
					System.out.println("Enter amount: ");float amount = sc.nextFloat();
					System.out.println("Account balance is"+bankingServices.withdrawAmount(accountNo, amount,pinNo));
				}catch (BankingServicesDownException e) {
					e.printStackTrace();
					System.out.println("Server is Down. Please try again later");
				}catch (AccountNotFoundException e) {
					System.out.println("Account not found");
				}catch (AccountBlockedException e) {
					System.out.println("Account is blocked");
				}catch (InsufficientAmountException e) {
					System.out.println("Account balance is low");
				}catch (InvalidPinNumberException e) {
					System.out.println("wrong pin");
				}break;

			case 4:
				try{
					System.out.println("Enter accountNoTo: ");long accountNoTo = sc.nextLong();
					System.out.println("Enter accountNoFrom: ");long accountNoFrom = sc.nextLong();
					System.out.println("Enter pin");int pinNo = sc.nextInt();
					System.out.println("Enter amount: ");float amount = sc.nextFloat();
					System.out.println("Transfer happened:"+bankingServices.fundTransfer(accountNoTo, accountNoFrom, amount, pinNo));
				}catch (BankingServicesDownException e) {
					System.out.println("Server is Down. Please try again later");
				}catch (AccountNotFoundException e) {
					System.out.println("Account not found");
				}catch (AccountBlockedException e) {
					System.out.println("Account is blocked");
				}catch (InsufficientAmountException e) {
					System.out.println("Account balance is low");
				}catch (InvalidPinNumberException e) {
					System.out.println("wrong pin");
				}break;

			case 5:
				try{
					System.out.println("Enter accountNo: ");long accountNo = sc.nextLong();
					Account  a = bankingServices.getAccountDetails(accountNo);
					System.out.println("Associate Details are: "+ a.toString());
				}catch (AccountNotFoundException e) {
					System.out.println("Account not found");
				} catch (BankingServicesDownException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}break;

			case 6:
				try {
					for (Account a: bankingServices.getAllAccountDetails())
						System.out.println(a.toString());
				} catch (BankingServicesDownException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;

			case 7:
				System.out.println("Enter accountNo: ");long accountNo = sc.nextLong();
				try {
					for (Transaction t: bankingServices.getAccountAllTransaction(accountNo))
						System.out.println(t.toString());
				} catch (BankingServicesDownException
						| AccountNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;

			case 8:
				System.out.println("Enter accountNo: ");long accountNo1 = sc.nextLong();
				try {
					System.out.println("Status is: "+bankingServices.accountStatus(accountNo1));
				} catch (BankingServicesDownException
						| AccountNotFoundException | AccountBlockedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
			System.out.println("\nDo you want to continue(y/n):");
			userChoice = sc.next();
		}
		sc.close();
		//		Address address = new Address(4012011, "Pune", "Maharashtra", "India");
		//		Customer customer = new Customer(101, "Shraddha", "Singh", address);
		//		/*Address address2 = customer.getAddress();
		//		 * System.out.println(address2.getCity());*/
		//		System.out.println(customer.getAddress().getCity());
		//		/*customer.getAddress().setCountry("New Country");*/
		//		customer.setAddress(new Address(226024, "Lucknow", "UP", "India"));
	}
}
