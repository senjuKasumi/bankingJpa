package com.cg.banking.DAOservices;

import java.util.ArrayList;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;

public interface AccountDAO {
	Account save(Account account);
	boolean update(Account account);
	Account findOne(long accountNo);
	ArrayList<Account> findAll();
	ArrayList<Transaction> findAllTransaction(long accountNo);
	
//	public ArrayList<Account> findAll();
}

