package com.cg.banking.services;
import java.sql.SQLException;
import java.util.List;

import com.cg.banking.DAOservices.AccountDAO;
import com.cg.banking.DAOservices.AccountDAOImpl;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices {

	private AccountDAO accountDAO = new AccountDAOImpl() ;

	@Override
	public long openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		Account account = new Account(accountType, initBalance);
		if(initBalance<500)
			throw new InvalidAmountException();
		if(accountType.equals("Savings")||accountType.equals("Current")||accountType.equals("Salary")){
			account=accountDAO.save(account);
			return account.getAccountNo();
		}
		return 0; 

	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account account = getAccountDetails(accountNo);
		if(account==null)
			throw new AccountNotFoundException();
		if(account.getStatus().equals("Blocked"))
			throw new AccountBlockedException();
		else{
			account.setAccountBalance(account.getAccountBalance()+amount);
			((Transaction) account.getTransaction()).setTransactionType("Deposit");
			accountDAO.update(account);
		}
		return account.getAccountBalance();
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account account = getAccountDetails(accountNo);
		if(account==null)
			throw new AccountNotFoundException();
		if(account.getAccountBalance()<amount)
			throw new InsufficientAmountException();
		if(account.getStatus().equals("Blocked"))
			throw new AccountBlockedException();
		if(account.getPinNumber()!=pinNumber)
			account.setStatus("Blocked");
		else{
			account.setAccountBalance(account.getAccountBalance()-amount);
			((Transaction) account.getTransaction()).setTransactionType("Withdraw");
			accountDAO.update(account);
		}
		return account.getAccountBalance();
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		//			try{		
		Account account1 = getAccountDetails(accountNoTo);
		Account account2 = getAccountDetails(accountNoFrom);
		if(account1==null||account2==null)
			throw new AccountNotFoundException();
		if(account2.getAccountBalance()<transferAmount)
			throw new InsufficientAmountException();
		if(account2.getPinNumber()!=pinNumber)
			throw new InvalidPinNumberException();
		if(account1.getStatus().equals("Blocked")||account2.getStatus().equals("Blocked"))
			throw new AccountBlockedException();
		if(pinNumber==account2.getPinNumber()){
			account1.setAccountBalance(account1.getAccountBalance()+((Transaction) account1.getTransaction()).getAmount());
			((Transaction) account1.getTransaction()).setTransactionType("Deposit");
			accountDAO.update(account1);
			((Transaction) account2.getTransaction()).setTransactionType("Withdraw");
			accountDAO.update(account2);
			return true;
		}
		else 
			return false;
	}

	@Override
	public Account getAccountDetails(long accountNo)throws AccountNotFoundException, BankingServicesDownException {
		Account account  = accountDAO.findOne(accountNo);
		if(account==null)
			throw new AccountNotFoundException();
		return account;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		return accountDAO.findAll();
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo){
		return accountDAO.findAllTransaction(accountNo);
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account account = getAccountDetails(accountNo);
		if(account==null)
			throw new AccountNotFoundException();
		if(account.getStatus().equals("Blocked"))
			throw new AccountBlockedException();
		return account.getStatus();
	}
}

